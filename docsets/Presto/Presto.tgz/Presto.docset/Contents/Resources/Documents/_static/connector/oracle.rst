================
Oracle Connector
================

The Oracle connector allows querying and creating tables in an
external Oracle database. This can be used to join data between
different systems like Oracle and Hive, or between two different
Oracle instances.

Configuration
-------------

To configure the Oracle connector, create a catalog properties file
in ``etc/catalog`` named, for example, ``oracle.properties``, to
mount the Oracle connector as the ``oracle`` catalog.
Create the file with the following contents, replacing the
connection properties as appropriate for your setup:

.. code-block:: none

    connector.name=oracle
    # The correct syntax of the connection-url varies by Oracle version and
    # configuration. The following example URL connects to an Oracle SID named
    # "orcl".
    # In some situations, the connection-url has to include the user and password.
    # example: connection-url=jdbc:oracle:thin:user/password@example.net:1521:orcl
    #
    connection-url=jdbc:oracle:thin:@example.net:1521:orcl
    connection-user=root
    connection-password=secret

The ``connection-url`` defines the connection information and parameters to pass
to the JDBC driver. The Oracle connector uses the Oracle JDBC Thin driver,
and the syntax of the URL may be different depending on your Oracle
configuration. For example, the connection URL is different if you are
connecting to an Oracle SID or an Oracle service name. See the `Oracle
Database JDBC driver documentation
<https://docs.oracle.com/en/database/oracle/oracle-database/21/jjdbc/data-sources-and-URLs.html#GUID-088B1600-C6C2-4F19-A020-2DAF8FE1F1C3>`_
for more information.

The ``connection-user`` and ``connection-password`` are typically required and
determine the user credentials for the connection, often a service user.

Multiple Oracle Servers
^^^^^^^^^^^^^^^^^^^^^^^

You can have as many catalogs as you need, so if you have additional
Oracle servers, simply add another properties file to ``etc/catalog``
with a different name (making sure it ends in ``.properties``). For
example, if you name the property file ``sales.properties``, Presto
will create a catalog named ``sales`` using the configured connector.

General Configuration Properties
---------------------------------

================================================== ==================================================================== ===========
Property Name                                      Description                                                          Default
================================================== ==================================================================== ===========
``user-credential-name``                           Name of the ``extraCredentials`` property whose value is the JDBC
                                                   driver's user name. See ``extraCredentials`` in
                                                   :ref:`Parameter Reference <jdbc-parameter-reference>`.

``password-credential-name``                       Name of the ``extraCredentials`` property whose value is the JDBC
                                                   driver's user password. See ``extraCredentials`` in
                                                   :ref:`Parameter Reference <jdbc-parameter-reference>`.

``case-insensitive-name-matching``                 Match dataset and table names case-insensitively.                    ``false``

``case-insensitive-name-matching.cache-ttl``       Duration for which remote dataset and table names will be
                                                   cached. Set to ``0ms`` to disable the cache.                         ``1m``

``list-schemas-ignored-schemas``                   List of schemas to ignore when listing schemas.                      ``information_schema``

``case-sensitive-name-matching``                   Enable case sensitive identifier support for schema and table        ``false``
                                                   names for the connector. When disabled, names are matched
                                                   case-insensitively using lowercase normalization.

``jdbc-fetch-size``                                Number of rows to fetch from the database at a time. Higher          ``20000``
                                                   values can improve performance for large result sets but may
                                                   increase memory usage.
================================================== ==================================================================== ===========

Oracle-Specific Configuration Properties
----------------------------------------

================================================== ==================================================================== ===========
Property Name                                      Description                                                          Default
================================================== ==================================================================== ===========
``oracle.tls.enabled``                             Enable TLS/SSL for secure connections to Oracle database.            ``false``

``oracle.tls.truststore-path``                     Path to the Java truststore file containing the Oracle server's
                                                   SSL certificate. Required when ``oracle.tls.enabled`` is ``true``.

``oracle.tls.truststore-password``                 Password for the truststore file. Required when
                                                   ``oracle.tls.enabled`` is ``true``.
================================================== ==================================================================== ===========

TLS/SSL Configuration
^^^^^^^^^^^^^^^^^^^^^

To enable secure connections to Oracle using TLS/SSL, configure the following properties:

.. code-block:: none

    oracle.tls.enabled=true
    oracle.tls.truststore-path=/path/to/truststore.jks
    oracle.tls.truststore-password=changeit

The truststore file must contain the Oracle server's SSL certificate or the certificate
authority (CA) certificate that signed the Oracle server's certificate.


Procedures
----------

Use the :doc:`/sql/call` statement to perform data manipulation or administrative tasks. Procedures are available in the ``system`` schema of the catalog.

Execute Procedure
^^^^^^^^^^^^^^^^^

Underlying datasources may support some operation or SQL syntax which is not supported by Presto, either at the parser level or at the connector level.
Trying to run such SQL statements in Presto can result in errors during parsing or analysing. For example, Oracle supports the DELETE statement which is not
supported in the Oracle connector. Running this procedure enables users to do a SQL passthrough to the underlying database, and Presto just acts as a middle man
for passing the statement.

The following arguments are available:

============= ========== =============== =======================================================================
Argument Name Required   Type            Description
============= ========== =============== =======================================================================
``QUERY``     Yes        string          SQL statement to run
============= ========== =============== =======================================================================

Examples:

* Delete a row from table `employees` where `employee_id = 101`::

    CALL oracle.system.execute('delete from employees where employee_id = 101')

    CALL oracle.system.execute(QUERY => 'delete from employees where employee_id = 101')



Querying Oracle
---------------

The Oracle connector provides a schema for every Oracle *database*.
You can see the available Oracle databases by running ``SHOW SCHEMAS``::

    SHOW SCHEMAS FROM oracle;

If you have a Oracle database named ``web``, you can view the tables
in this database by running ``SHOW TABLES``::

    SHOW TABLES FROM oracle.web;

You can see a list of the columns in the ``clicks`` table in the ``web`` database
using either of the following::

    DESCRIBE oracle.web.clicks;
    SHOW COLUMNS FROM oracle.web.clicks;

Finally, you can access the ``clicks`` table in the ``web`` database::

    SELECT * FROM oracle.web.clicks;

If you used a different name for your catalog properties file, use
that catalog name instead of ``oracle`` in the above examples.

Type mapping
------------

PrestoDB and Oracle each support types that the other does not. When reading from Oracle, Presto converts
the data types from Oracle to equivalent Presto data types.
Refer to the following section for type mapping in each direction.

Oracle to PrestoDB type mapping
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

The connector maps Oracle types to the corresponding PrestoDB types:

.. list-table:: Oracle to PrestoDB type mapping
  :header-rows: 1

  * - Oracle type
    - PrestoDB type
  * - ``BLOB``
    - ``VARBINARY``
  * - ``BINARY_FLOAT``
    - ``REAL``
  * - ``REAL``
    - ``REAL``
  * - ``BINARY_DOUBLE``
    - ``DOUBLE``

Oracle Connector Limitations
----------------------------

The following SQL statements are not yet supported:

* :doc:`/sql/delete`
* :doc:`/sql/grant`
* :doc:`/sql/revoke`
* :doc:`/sql/show-grants`
* :doc:`/sql/show-roles`
* :doc:`/sql/show-role-grants`
