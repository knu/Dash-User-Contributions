========================
Oauth 2.0 Authentication
========================

Presto can be configured to enable frontend OAuth2 authentication over HTTPS for clients such as the CLI, JDBC, and ODBC drivers. OAuth2 provides a secure and flexible way to authenticate users by using an external identity provider (IdP), such as Okta, Auth0, Azure AD, or Google.

OAuth2 authentication in Presto uses the Authorization Code Flow with PKCE and OpenID Connect (OIDC). The Presto coordinator initiates an OAuth2 challenge, and the client completes the flow by obtaining an access token from the identity provider.

Presto Server Configuration
---------------------------

To enable OAuth2 authentication, configuration changes are made **only on the Presto coordinator**. No changes are required on the workers.

Secure Communication
--------------------

Access to the Presto coordinator must be secured with HTTPS. You must configure a valid TLS certificate and keystore on the coordinator.
See the :doc:`TLS setup guide </security/internal-communication>` for details.

OAuth2 Configuration
--------------------

Below are the key configuration properties for enabling OAuth2 authentication in ``config.properties``:

.. code-block:: properties

    http-server.authentication.type=OAUTH2

    http-server.authentication.oauth2.issuer=https://your-idp.com/oauth2/default
    http-server.authentication.oauth2.client-id=your-client-id
    http-server.authentication.oauth2.client-secret=your-client-secret
    http-server.authentication.oauth2.scopes=openid,email,profile
    http-server.authentication.oauth2.principal-field=sub
    http-server.authentication.oauth2.groups-field=groups
    http-server.authentication.oauth2.challenge-timeout=15m
    http-server.authentication.oauth2.max-clock-skew=1m
    http-server.authentication.oauth2.refresh-tokens=true
    http-server.authentication.oauth2.oidc.discovery=true
    http-server.authentication.oauth2.authorization-endpoint=https://your-idp.com/oauth2/authorize
    http-server.authentication.oauth2.state-key=your-hmac-secret
    http-server.authentication.oauth2.additional-audiences=your-client-id,another-audience
    http-server.authentication.oauth2.user-mapping.pattern=(.*)
    http-server.authentication.oauth2.userinfo-cache=false
    http-server.authentication.oauth2.userinfo-cache-ttl=10m

It is worth noting that ``configuration-based-authorizer.role-regex-map.file-path`` must be configured if
authentication type is set to ``OAUTH2``.

TLS Truststore for IdP
----------------------

If your IdP uses a custom or self-signed certificate, import it into the Java truststore on the Presto coordinator:

.. code-block:: bash

    keytool -import \
      -keystore $JAVA_HOME/lib/security/cacerts \
      -trustcacerts \
      -alias idp_cert \
      -file idp_cert.crt

Notes
-----

- **Issuer**: The base URL of your IdP's OIDC discovery endpoint.
- **Client ID/Secret**: Registered credentials for Presto in your IdP.
- **Scopes**: Must include ``openid``; others like ``email``, ``profile``, or ``groups`` are optional.
- **Principal Field**: The claim used as the Presto username. For OIDC flows (when ``openid`` scope is included), this is extracted from the ID token. If the claim is not present in the ID token, Presto will query the UserInfo endpoint as a fallback. For pure OAuth2 flows (without ``openid`` scope), the UserInfo endpoint is queried first, with the access token as a last resort.
- **Groups Field**: Optional claim used for role-based access control.
- **State Key**: A secret used to sign the OAuth2 state parameter (HMAC).
- **Refresh Tokens**: Enable if your IdP supports issuing refresh tokens.
- **Authorization Endpoint**: Optional. Use this to specify a custom authorization endpoint for IdPs that have separate authorization endpoints and issuers. When not specified, the authorization endpoint is discovered from the IdP's OIDC discovery document (if ``oidc.discovery=true``) or derived from the issuer URL.
- **UserInfo Cache**: Enable caching of UserInfo endpoint responses to reduce load on the IdP and improve performance. When enabled, responses are cached using a SHA-256 hash of the access token as the key. Default is ``false``.
- **UserInfo Cache TTL**: Time-to-live for cached UserInfo entries. Only applicable when ``userinfo-cache`` is enabled. Default is ``10m`` (10 minutes). Minimum value is ``1m``.
- **Callback**: When configuring your IdP the callback URI must be set to ``[presto]/oauth2/callback``

Presto CLI with OAuth2
----------------------

To use the Presto CLI with OAuth2 authentication, you must enable external authentication and specify how the OAuth2 redirect should be handled.

Basic usage:

.. code-block:: bash

    ./presto --server https://presto-coordinator.example.com:8443 \
      --external-authentication \
      --external-authentication-redirect-handler OPEN

Available redirect handlers:

- ``OPEN``: Automatically opens the authorization URL in your default web browser (recommended for desktop environments)
- ``PRINT``: Prints the authorization URL to the console for manual copy-paste (useful for remote/headless environments)
- ``DESKTOP``: Uses Java Desktop API to open the browser (alternative to OPEN)

Example with truststore configuration:

.. code-block:: bash

    ./presto --server https://presto-coordinator.example.com:8443 \
      --external-authentication \
      --external-authentication-redirect-handler OPEN \
      --truststore-path /path/to/truststore.jks \
      --truststore-password truststore_password

When you run the CLI with external authentication enabled, it will:

1. Initiate an OAuth2 authentication flow with the Presto coordinator
2. Open your browser (or print a URL) to complete authentication with your identity provider
3. Wait for the OAuth2 callback to complete
4. Establish an authenticated session with the Presto coordinator

See :doc:`/clients/presto-cli` for more CLI options and usage information.
